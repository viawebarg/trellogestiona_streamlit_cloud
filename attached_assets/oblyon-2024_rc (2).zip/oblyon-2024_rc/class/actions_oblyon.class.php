<?php
/* Copyright (C) 2022 Paul LEPONT           <paul@kawagency.fr>
/* Copyright (C) 2022 Alexandre Spangaro    <alexandre@inovea-conseil.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

/**
 * Class ActionsOblyon
 */
class ActionsOblyon
{
	/**
	 * @var DoliDB Database handler.
	 */
	public $db;

	/**
	 * @var string Error code (or message)
	 */
	public $error = '';

	/**
	 * @var array Errors
	 */
	public $errors = array();


	/**
	 * @var array Hook results. Propagated to $hookmanager->resArray for later reuse
	 */
	public $results = array();

	/**
	 * @var string String displayed by executeHook() immediately after return
	 */
	public $resprints;

	/**
	 * Constructor
	 *
	 *  @param		DoliDB		$db      Database handler
	 */
	public function __construct($db)
	{
		$this->db = $db;
	}

    /*
	public function addHtmlHeader($parameters){
		global $conf;

		$style = "<style id='oblyon_custom_css'>";
		if (getDolGlobalString('OBLYON_CUSTOM_CSS')){
			$style .= getDolGlobalString('OBLYON_CUSTOM_CSS');
		}
		$style .= "</style>";
		
		$this->resprints = $style;
		return 0;
	}
    */
}
