<a href="https://www.inovea-conseil.com" target="_blank">![IC](https://www.dolibiz.com/wp-content/uploads/2017/09/inovea.png "Inovea Conseil expert Dolibarr")</a>
<a href="https://www.dolibiz.com" target="_blank">![Dolibiz](https://www.dolibiz.com/wp-content/uploads/2017/09/dolibiz.png "Consultez dolibiz.com")</a>
<a href="https://www.dolistore.com/fr/recherche?search_query=inovea+conseil&submit_search=&orderby=reference&orderway=desc" target="_blank">![Dolistore](https://www.dolibiz.com/wp-content/uploads/2017/09/dolistore.png "Consultez dolistore.com")</a>
![DPP](https://www.dolibiz.com/wp-content/uploads/2017/09/dpp.png "Inovea Conseil Dolibarr Preferred Partner")
<a href="https://www.dolibiz.com/support/" target="_blank">![Support](https://www.dolibiz.com/wp-content/uploads/2017/09/support.png "Support")</a>

Ce module a été développé par Inovea Conseil - votre partenaire Dolibarr pour tout développement de modules sur-mesure, de la formation et de l'hébergement Dolibarr.
* Retrouvez la documentation de votre module sur <a href="https://www.dolibiz.com/support/" target="_blank">notre support en ligne</a>
* Vous pourrez découvrir nos autres modules et services sur <a href="https://www.dolibiz.com" target="_blank">notre site dolibiz.com</a>

## Comment utiliser

Pour utiliser le thème, vous devez **activer** le module. Lors de l'activation du module, le thème sera automatiquement activé.

**Avertissements** :
* L'activation du thème seul entraînera des comportements inattendus !
* Changer le thème dans Dolibarr dans les paramètres du profil de l'utilisateur alors que le module Oblyon est actif entraînera également des comportements inattendus !

## Questions / Demandes

Les idées et les suggestions sont les bienvenues. N'hésitez pas à créer un problème ou un PR sur Github en utilisant [github.com/aspangaro/oblyon](https://github.com/aspangaro/oblyon).

Pour tout besoin, vous pouvez nous contacter : <a href="mailto:info@inovea-conseil.com">info@inovea-conseil.com</a>

-------------------------

Developed by Inovea Conseil - your Dolibarr partner (developpement, hosting and training).
* You can find the documentation for your module in our <a href="https://www.dolibiz.com/support/" target="_blank">online support</a>
* Discorver our modules and services on <a href="https://www.dolibiz.com" target="_blank">our website www.dolibiz.com</a>

Please contact us for any question : <a href="mailto:info@inovea-conseil.com">info@inovea-conseil.com</a>

## How to use

To use the theme, you **must** activate the module. When activating the module, the theme will automatically be activated as well.

**Warnings**:
* Activating the theme alone will result in unexpected behaviors!
* Changing the theme in Dolibarr in the user profile settings while the Oblyon module is active will also result in unexpected behaviors!

## Issues / Request

Ideas and suggestions are welcome. Feel free to create an issue or PR on Github using at [github.com/aspangaro/oblyon](https://github.com/aspangaro/oblyon).

![GPL](https://www.dolibiz.com/wp-content/uploads/2017/09/gpl.png "Licence GPL v3")