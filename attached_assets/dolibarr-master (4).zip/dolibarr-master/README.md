# TECLIB MODULES FOR DOLIBARR ERP & CRM

Repository of all Teclib modules (https://www.teclib.com) for Dolibarr ERP CRM (https://www.dolibarr.org)


![TecLib Logo](logo_teclib.png?raw=true "Logo TecLib")

![Dolibarr Logo](dolibarr_logo.png?raw=true "Logo Dolibarr")



## LICENSE

All TecLib modules are released under the terms of the GNU General Public License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version (GPL-3+).

See the [COPYING](https://github.com/Dolibarr/dolibarr/blob/develop/COPYING) file for a full copy of the license.


## CONTRIBUTE

Feel free to contribute to any modules by sending Pull Request on GitHub (https://github.com/TECLIB/dolibarr)


## ABOUT TECLIB

TecLib is an Open Source company that provide the service NovaFirstcloud.com (https://www.novafirstcloud.com), one of the most famous hosting service for 
Dolibarr ERP CRM software.




