# CHANGELOG ADVANCED NOTES FOR <a href="https://www.dolibarr.org">DOLIBARR ERP CRM</a>


## 1.0.1

- Compatibility v16+ and PHP8

## 1.0

- Initial version