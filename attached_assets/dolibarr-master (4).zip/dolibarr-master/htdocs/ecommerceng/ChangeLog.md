# ChangeLog

## 5.0

- Compatibility v11+

## 4.0

- Add option ECOMMERCENG_BANK_ID_FOR_PAYMENT so payments are now recorded.
- Manage Magento shopping cart/coupon discounts.
- Add option ECOMMERCENG_ENABLE_LOG_IN_NOTE

## 3.9.1.0

- Add option ECOMMERCENG_THIRDPARTY_UNIQUE_ON to search existing thirdparties from email instead of name.
- Can define to_date=YYYYMMDDHHMMSS in url to limit date when searching updated records.
- Add option ECOMMERCENG_DEBUG to log Soap requests with magento.
- Add support for Woocommerce.
- Support for price level.
- A lot of fix/enhancement in error management.

## 3.9.0.0

- Initial version.
