ALTER TABLE llx_ecommerce_site ADD COLUMN price_level integer NULL DEFAULT 1;
