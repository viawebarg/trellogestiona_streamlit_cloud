
= Magento backoffice

The base_url of magento is defined into table core_config_data.

Admin URL: http://mymagento/index.php/admin/


= Magento frontoffice

To see a product into magento shop, you must have "Stock Availability" set to yes.


= Magento dev

Note about status in Magento: https://black.bird.eu/fr/blog/comprendre-les-etats-des-commandes-dans-magento.html
