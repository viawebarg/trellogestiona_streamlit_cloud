# Hack for woocommerce.
For authentification with api legacy v3 for the url with index.php in it.

Override the file in the wordpress folder.