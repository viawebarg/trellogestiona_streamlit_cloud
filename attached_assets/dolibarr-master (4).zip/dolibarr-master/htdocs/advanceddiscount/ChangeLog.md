# CHANGELOG ADVANCED DISCOUNTS MODULE FOR <a href="https://www.dolibarr.org">DOLIBARR ERP CRM</a>

## 1.3.1

- FIX Support selection of discount on product category
- FIX Management of several discounts on the same object.

## 1.3

- NEW Support selection of discount on product category

## 1.2

- FIX error no default value for tms

## 1.1

- Compatibility v11+

## 1.0.1

- FIX error 500 when using categories

## 1.0

- Initial version

