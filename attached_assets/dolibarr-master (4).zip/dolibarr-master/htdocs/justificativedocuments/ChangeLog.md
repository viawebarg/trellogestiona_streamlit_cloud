# CHANGELOG SUPPORTING DOCUMENTS FOR <a href="https://www.dolibarr.org">DOLIBARR ERP CRM</a>


## 2.0
- Compatibility v11+

## 1.0
- Initial version

