# AUTOATTACHFILES MODULE FOR <a href="https://www.dolibarr.org">DOLIBARR ERP CRM</a>

## Features
Automatically attach files to email form (proposals, orders, invoices)

Objects that are supported:

* Customer proposals
* Customer orders
* Customer invoices

More information <a href="https://wiki.dolibarr.org/index.php/Module_AutoAttachFile" target="_new">this wiki page</a>.
