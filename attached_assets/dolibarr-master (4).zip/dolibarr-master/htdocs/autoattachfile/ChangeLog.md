# ChangeLog MODULE AUTOATTACHFILE FOR <a href="https://www.dolibarr.org">DOLIBARR ERP CRM</a>


# 7.1

Fix compatibility with predefined email templates
Support interventions too.
Support supplier proposals, orders and invoices too.

# 7.0

Compatibility with dolibarr 7.0

# 4.0

Compatibility with dolibarr 4.0

## 1.0

Initial version
