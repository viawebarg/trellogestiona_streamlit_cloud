INSERT INTO llx_kimios_config (url ,userName,password,userSource,initialPath)
VALUES ('http://ip:9999/kimios','admin','kimios','kimios','ERP');