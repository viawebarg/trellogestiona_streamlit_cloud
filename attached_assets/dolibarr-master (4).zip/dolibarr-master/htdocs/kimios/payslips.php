<?php
/*
 LICENSE

 This file is part of the Kimios Dolibarr module.

 Kimios Dolibarr module is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 Kimios Dolibarr module is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with Kimios Dolibarr module. If not, see <http://www.gnu.org/licenses/>.
 --------------------------------------------------------------------------
 @package   Kimios-Dolibarr
 @author    teclib (François Legastelois)
 @copyright Copyright (c) 2016 teclib'
 @license   GPLv2+
            http://www.gnu.org/licenses/gpl.txt
 @link      http://www.teclib.com
 @since     2013
 ---------------------------------------------------------------------- */

$res=0;
// Try main.inc.php into web root known defined into CONTEXT_DOCUMENT_ROOT (not always defined)
if (! $res && ! empty($_SERVER["CONTEXT_DOCUMENT_ROOT"])) $res=@include($_SERVER["CONTEXT_DOCUMENT_ROOT"]."/main.inc.php");
// Try main.inc.php into web root detected using web root caluclated from SCRIPT_FILENAME
$tmp=empty($_SERVER['SCRIPT_FILENAME'])?'':$_SERVER['SCRIPT_FILENAME'];$tmp2=realpath(__FILE__); $i=strlen($tmp)-1; $j=strlen($tmp2)-1;
while($i > 0 && $j > 0 && isset($tmp[$i]) && isset($tmp2[$j]) && $tmp[$i]==$tmp2[$j]) { $i--; $j--; }
if (! $res && $i > 0 && file_exists(substr($tmp, 0, ($i+1))."/main.inc.php")) $res=@include(substr($tmp, 0, ($i+1))."/main.inc.php");
if (! $res && $i > 0 && file_exists(dirname(substr($tmp, 0, ($i+1)))."/main.inc.php")) $res=@include(dirname(substr($tmp, 0, ($i+1)))."/main.inc.php");
// Try main.inc.php using relative path
if (! $res && file_exists("../main.inc.php")) $res=@include("../main.inc.php");
if (! $res && file_exists("../../main.inc.php")) $res=@include("../../main.inc.php");
if (! $res && file_exists("../../../main.inc.php")) $res=@include("../../../main.inc.php");
if (! $res) die("Include of main fails");

require_once DOL_DOCUMENT_ROOT.'/core/class/html.formother.class.php';
include_once DOL_DOCUMENT_ROOT.'/core/class/html.formmail.class.php';
require_once DOL_DOCUMENT_ROOT.'/core/class/CMailFile.class.php';

dol_include_once('/kimios/class/db.class.php');
dol_include_once('/kimios/class/config.class.php');
dol_include_once('/kimios/class/api/bootstrap.php');
dol_include_once('/kimios/class/actions_kimios.class.php');
dol_include_once('/kimios/class/payslips.class.php');

define('_KIMIOS_EXEC',true);

if (!$user->rights->kimios->send_payslips) accessforbidden();

$step = GETPOST("step")?GETPOST("step"):1;
$action = GETPOST("action")?GETPOST("action"):1;

$KimiosPhpSoap = new KimiosPhpSoap();
$ActionsKimios = new ActionsKimios();
$KimiosPayslips = new KimiosPayslips();
$KimiosConfig  = new KimiosConfig();
$KimiosConfig->getFromDB(1);

$sessionId = $ActionsKimios->connect();

if ($action == 'download') {
   $payslips_rowid = GETPOST("payslips_rowid")?GETPOST("payslips_rowid"):1;
   KimiosPayslips::download($payslips_rowid);
}

llxHeader();

$h = 0;
for ($i = 1; $i < $step+1; $i++) {
   $head[$h][0] = DOL_URL_ROOT.'/teclib/kimios/payslips.php';
   $head[$h][1] = $langs->trans("Step")." ".$i;
   if ($i == $step) $hselected=$h;
   $h++;
}

dol_fiche_head($head, $hselected, "Envoi fiches de paie");

print '<table class="notopnoleftnoright" width="100%">';
   KimiosPayslips::showStep($step);
print '</table>';

llxFooter();
