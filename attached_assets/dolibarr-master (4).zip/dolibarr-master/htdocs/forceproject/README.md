# FORCEPROJECT FOR <a href="https://www.dolibarr.org">DOLIBARR ERP CRM</a>

## Features

Check a project is linked to allow to validate proposal or order. 
It may also replace key 'projectref' or {PROJECTREF-X} (with X = length of a project ref) 
with ref of linked project, if the key is found into the mask of numbering.



Licenses
--------

### Main code

![GPLv3 logo](img/gplv3.png)

GPLv3 or (at your option) any later version.

See [COPYING](COPYING) for more information.

#### Documentation

All texts and readmes.

![GFDL logo](img/gfdl.png)
