# CHANGELOG FORCEPROJECT FOR <a href="https://www.dolibarr.org">DOLIBARR ERP CRM</a>

## 1.0.2
FIX Compatibility with dolibarr1 (facnumber -> ref)

## 1.0.1
FIX Can set FORCEPROJECT_COUNTER_FOREACH_PROJECT and avoid increase of ref number by step of 2

## 1.0
Initial version

