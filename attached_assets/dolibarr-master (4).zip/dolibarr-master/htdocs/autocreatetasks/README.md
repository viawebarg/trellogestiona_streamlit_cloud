# AUTOCREATETASKS FOR [DOLIBARR ERP CRM](https://www.dolibarr.org)

## Features

Create some tasks automatically from a list of predefined tasks labels.
Creation is done on project validation.



Other modules are available on [Dolistore.com](https://www.dolistore.com>).

## Translations

Translations can be define manually by editing files into directories *langs*.





## Licenses

### Main code

GPLv3 or (at your option) any later version. See file COPYING for more information.

### Documentation

All texts and readmes are licensed under GFDL.
