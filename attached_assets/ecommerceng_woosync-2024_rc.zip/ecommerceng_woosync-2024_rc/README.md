WooSync
========================
Module de synchronisation entre Dolibarr et les plateformes e-commerce WooCommerce.


## Documentation


Lien vers notre [documentation](https://link.easya.solutions/woosync_doc)



<!-- # WooSync, synchronize Woocommerce and Dolibarr

## You have to rename the folder to ecommerceng when you download the zip file or make a git clone. In other case the module will not work

Use it at you onwn risk Easya Solution does not provide support for the use, installation or bug fixing for this software. For this you have to acquire a time from our sales service https://www.easya.solutions/contact. You can also consult our company for any installation, configuration or development services. 

Before any use, please refer to the documentation to check the available functionnality
https://link.easya.solutions/woosync_doc


Utilisation à vos risques et périls. Easya Solutions ne fournit pas de support à l’utilisation, à l'installation ni de correction de bugs pour ce logiciel. Pour cela vous devrez faire l’acquisition d’un crédit temps auprès de notre service commercial : https://www.easya.solutions/contact. Vous pouvez également nous consulter pour toute prestation d’installation, configuration ou développement. 

Avant toute utilisation, merci de prendre connaissance de la documentation pour vérifier si le module répond en l'état à vos besoins
https://link.easya.solutions/woosync_doc -->

