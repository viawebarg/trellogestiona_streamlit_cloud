<?php
$declared_rates = array(
	array(
		'tax_rate_country'  => 'IT',
		'tax_rate'          => '22',
		'tax_rate_name'     => $tax_name,
		'tax_rate_priority' => '1',
		'tax_rate_order'    => '0',
		'tax_rate_class'    => '',
	),
	array(
		'tax_rate_country'  => 'IT',
		'tax_rate'          => '10',
		'tax_rate_name'     => $tax_name,
		'tax_rate_priority' => '1',
		'tax_rate_order'    => '0',
		'tax_rate_class'    => 'reduced',
	),
	array(
		'tax_rate_country'  => 'IT',
		'tax_rate'          => '4',
		'tax_rate_name'     => $tax_name,
		'tax_rate_priority' => '1',
		'tax_rate_order'    => '0',
		'tax_rate_class'    => 'super-reduced',
	),
);
