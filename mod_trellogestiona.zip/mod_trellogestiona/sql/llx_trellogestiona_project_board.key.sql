-- ===================================================================
-- Copyright (C) 2024 VIAWEB S.A.S
-- ===================================================================

-- Las claves ya están definidas en el archivo de creación de tabla
-- Este archivo se mantiene para compatibilidad con el sistema de instalación de Dolibarr